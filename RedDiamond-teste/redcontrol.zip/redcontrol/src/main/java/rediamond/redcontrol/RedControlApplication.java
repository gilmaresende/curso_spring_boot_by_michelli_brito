package rediamond.redcontrol;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedControlApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedControlApplication.class, args);
	}

}
