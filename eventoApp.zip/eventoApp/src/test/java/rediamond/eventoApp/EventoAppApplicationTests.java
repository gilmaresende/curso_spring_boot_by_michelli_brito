package rediamond.eventoApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
